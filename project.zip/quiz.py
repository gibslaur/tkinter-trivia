from tkinter import *
from PIL import ImageTk, Image
import random

root = Tk()
root.title("Quiz")
root.geometry("500x500")

# start text
start_text = Label(root, text="Start your trivia quiz!")
start_text.pack(pady=20)
# start image
global start_image
start_image = ImageTk.PhotoImage(Image.open("start.jpg").resize((250, 250)))
image_label = Label(root, image=start_image).pack(pady=20)


# second window function
def open_win():
    global start_image
    top = Toplevel()
    top.title("Questions")
    top.geometry("500x250")
    # get random question from list
    lines = open('questions.txt').read().splitlines()
    myline = random.choice(lines)
    questions = Label(top, text=myline).pack(pady=15)

    # answer choice buttons
    Radiobutton(top, text="Option 1", variable=r, value=1, command=lambda: clicked(r.get())).pack()
    Radiobutton(top, text="Option 2", variable=r, value=2, command=lambda: clicked(r.get())).pack()
    Radiobutton(top, text="Option 3", variable=r, value=3, command=lambda: clicked(r.get())).pack()
    Radiobutton(top, text="Option 4", variable=r, value=4, command=lambda: clicked(r.get())).pack()

    # submit button
    submit_button = Button(top, text="Submit").pack(pady=5)
    # next question button
    next_button = Button(top, text="Next").pack()


# second window button
window_button = Button(root, text="Begin quiz", command=open_win).pack()
# quit button
quit_button = Button(root, text="Quit", command=root.destroy).pack(pady=5)

r = IntVar()
r.set("1")


def clicked(value):
    my_label = Label(root, text=value)
    my_label.pack()

mainloop()
